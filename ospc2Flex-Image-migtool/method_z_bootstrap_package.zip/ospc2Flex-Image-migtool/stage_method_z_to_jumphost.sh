#!/usr/bin/env bash
set -Eeuo pipefail

JUMPHOST=""
SSH_KEY=""
REMOTE_BASE="/mnt/migration/ospc2flex_method_z"
BOOTSTRAP=0
DOWNLOAD_VIRTIO=0
CHECK_OPENSTACK=0
REGION="DFW3"
DRY_RUN=0
COPY_OPENRC=0
OPENRC_PATH=""
LOCAL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MANIFEST="$LOCAL_DIR/method_z_required_files.txt"
TS="$(date -u +%Y%m%dT%H%M%SZ)"
LOG_FILE="$LOCAL_DIR/stage-method-z-$TS.log"

usage() {
  cat <<USAGE
Usage: $0 --jumphost user@host --ssh-key PATH [options]

Options:
  --jumphost USER@HOST       Remote jumphost
  --ssh-key PATH             SSH private key
  --remote-base PATH         Remote Method Z base. Default: $REMOTE_BASE
  --bootstrap                Run remote bootstrap after copy
  --download-virtio          Bootstrap downloads virtio-win.iso if missing
  --check-openstack          Bootstrap validates OpenStack auth/region on remote
  --region REGION            Region for OpenStack image check. Default: DFW3
  --copy-openrc PATH         Explicitly copy OpenRC to remote conf/ (disabled by default)
  --dry-run                  Print commands only
  -h, --help                 Show help
USAGE
}

log() { printf '[%s] %s\n' "$(date -u +%FT%TZ)" "$*" | tee -a "$LOG_FILE"; }
run() { log "+ $*"; [[ "$DRY_RUN" == "1" ]] || "$@" 2>&1 | tee -a "$LOG_FILE"; }
ssh_cmd() { ssh -i "$SSH_KEY" -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "$JUMPHOST" "$@"; }
scp_file() { scp -i "$SSH_KEY" -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "$1" "$JUMPHOST:$2"; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --jumphost) JUMPHOST="$2"; shift 2 ;;
    --ssh-key) SSH_KEY="$2"; shift 2 ;;
    --remote-base) REMOTE_BASE="$2"; shift 2 ;;
    --bootstrap) BOOTSTRAP=1; shift ;;
    --download-virtio) DOWNLOAD_VIRTIO=1; shift ;;
    --check-openstack) CHECK_OPENSTACK=1; shift ;;
    --region) REGION="$2"; shift 2 ;;
    --copy-openrc) COPY_OPENRC=1; OPENRC_PATH="$2"; shift 2 ;;
    --dry-run) DRY_RUN=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage; exit 2 ;;
  esac
done

[[ -n "$JUMPHOST" ]] || { usage; exit 2; }
[[ -n "$SSH_KEY" && -f "$SSH_KEY" ]] || { echo "SSH key not found: $SSH_KEY" >&2; exit 2; }
[[ -f "$MANIFEST" ]] || { echo "Manifest not found: $MANIFEST" >&2; exit 1; }

log "Staging Method Z to $JUMPHOST:$REMOTE_BASE"
log "Secrets are not copied by default. Use --copy-openrc only when explicitly required."

missing=()
while IFS= read -r f; do
  [[ -z "$f" || "$f" =~ ^# ]] && continue
  if [[ ! -f "$LOCAL_DIR/$f" ]]; then missing+=("$f"); fi
done < "$MANIFEST"
[[ ${#missing[@]} -eq 0 ]] || { printf 'Missing required local files:\n%s\n' "${missing[*]}" >&2; exit 1; }

run ssh -i "$SSH_KEY" -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "$JUMPHOST" \
  "sudo mkdir -p '$REMOTE_BASE/bin' '$REMOTE_BASE/conf' '$REMOTE_BASE/logs' '$REMOTE_BASE/reports' '$REMOTE_BASE/cache/virtio' '$REMOTE_BASE/runs' '$REMOTE_BASE/tmp' '$REMOTE_BASE/bad_artifacts' && sudo chown -R \$(id -u):\$(id -g) '$REMOTE_BASE'"

while IFS= read -r f; do
  [[ -z "$f" || "$f" =~ ^# ]] && continue
  run scp -i "$SSH_KEY" -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "$LOCAL_DIR/$f" "$JUMPHOST:$REMOTE_BASE/bin/$f"
done < "$MANIFEST"

run ssh -i "$SSH_KEY" -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "$JUMPHOST" \
  "chmod +x '$REMOTE_BASE'/bin/*.sh"

if [[ "$COPY_OPENRC" == "1" ]]; then
  [[ -f "$OPENRC_PATH" ]] || { echo "OpenRC not found: $OPENRC_PATH" >&2; exit 2; }
  log "Explicit --copy-openrc requested. Copying OpenRC to remote conf with chmod 600."
  run scp -i "$SSH_KEY" -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "$OPENRC_PATH" "$JUMPHOST:$REMOTE_BASE/conf/flex-openrc.sh"
  run ssh -i "$SSH_KEY" -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "$JUMPHOST" \
    "chmod 600 '$REMOTE_BASE/conf/flex-openrc.sh'"
fi

if [[ "$BOOTSTRAP" == "1" ]]; then
  args=("--base-dir" "$REMOTE_BASE" "--virtio-iso" "$REMOTE_BASE/cache/virtio/virtio-win.iso" "--region" "$REGION")
  [[ "$DOWNLOAD_VIRTIO" == "1" ]] && args+=("--download-virtio")
  [[ "$CHECK_OPENSTACK" == "1" ]] && args+=("--check-openstack")
  remote_cmd="'$REMOTE_BASE/bin/bootstrap_method_z_jumphost.sh'"
  for a in "${args[@]}"; do remote_cmd+=" '$(printf "%s" "$a" | sed "s/'/'\\''/g")'"; done
  if [[ "$COPY_OPENRC" == "1" ]]; then
    remote_cmd="source '$REMOTE_BASE/conf/flex-openrc.sh' && $remote_cmd"
  fi
  run ssh -i "$SSH_KEY" -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "$JUMPHOST" "$remote_cmd"
fi

log "Method Z staging complete."
log "Remote scripts are in: $REMOTE_BASE/bin/"

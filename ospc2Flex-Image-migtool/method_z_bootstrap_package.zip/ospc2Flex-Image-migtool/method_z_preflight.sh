#!/usr/bin/env bash
set -Eeuo pipefail

BASE_DIR="${OSPC2FLEX_METHOD_Z_BASE_DIR:-/mnt/migration/ospc2flex_method_z}"
VIRTIO_ISO="${OSPC2FLEX_VIRTIO_ISO:-$BASE_DIR/cache/virtio/virtio-win.iso}"
REGION="${OS_REGION_NAME:-DFW3}"
SOURCE_ARTIFACT=""
REPORT="$BASE_DIR/reports/preflight_status.json"
FAILURE_REASON=""
NEXT_ACTION=""
ACTUAL_IMAGE_REGION=""

usage() {
  cat <<USAGE
Usage: $0 [options]

Options:
  --base-dir PATH
  --virtio-iso PATH
  --region REGION
  --source-artifact PATH   Optional source artifact for disk-space sizing
  -h, --help
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --base-dir) BASE_DIR="$2"; shift 2 ;;
    --virtio-iso) VIRTIO_ISO="$2"; shift 2 ;;
    --region) REGION="$2"; shift 2 ;;
    --source-artifact) SOURCE_ARTIFACT="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage; exit 2 ;;
  esac
done
REPORT="$BASE_DIR/reports/preflight_status.json"
mkdir -p "$(dirname "$REPORT")"

json_escape() { python3 -c 'import json,sys; print(json.dumps(sys.argv[1]))' "$1"; }
write_status() {
  local status="$1"
  cat > "$REPORT" <<JSON
{
  "component": "method_z_preflight",
  "status": "$status",
  "base_dir": $(json_escape "$BASE_DIR"),
  "virtio_iso": $(json_escape "$VIRTIO_ISO"),
  "requested_region": $(json_escape "$REGION"),
  "actual_image_region": $(json_escape "$ACTUAL_IMAGE_REGION"),
  "source_artifact": $(json_escape "$SOURCE_ARTIFACT"),
  "failure_reason": $(json_escape "$FAILURE_REASON"),
  "next_action": $(json_escape "$NEXT_ACTION"),
  "timestamp": "$(date -u +%FT%TZ)"
}
JSON
}
fail() { FAILURE_REASON="$1"; NEXT_ACTION="${2:-Fix the preflight issue and rerun.}"; write_status FAILED; echo "METHOD_Z_PREFLIGHT_FAILED: $FAILURE_REASON" >&2; echo "NEXT_ACTION: $NEXT_ACTION" >&2; exit 1; }

[[ -d "$BASE_DIR" ]] || fail "BASE_DIR_MISSING" "Run bootstrap_method_z_jumphost.sh first."

required=(qemu-img qemu-nbd guestmount guestunmount hivexsh reged chntpw openstack jq curl nc ssh scp rsync python3)
missing=()
for c in "${required[@]}"; do command -v "$c" >/dev/null 2>&1 || missing+=("$c"); done
[[ ${#missing[@]} -eq 0 ]] || fail "REQUIRED_TOOLS_MISSING" "Missing: ${missing[*]}. Run bootstrap."

[[ -s "$VIRTIO_ISO" ]] || fail "VIRTIO_ISO_MISSING" "Run bootstrap with --download-virtio."
file "$VIRTIO_ISO" | grep -qi 'ISO 9660' || fail "VIRTIO_ISO_INVALID" "Replace $VIRTIO_ISO with a valid virtio-win.iso."

tmp_iso="$(mktemp -d "$BASE_DIR/tmp/preflight-virtio.XXXXXX")"
cleanup_iso() { sudo umount "$tmp_iso" >/dev/null 2>&1 || true; rmdir "$tmp_iso" >/dev/null 2>&1 || true; }
trap cleanup_iso EXIT
sudo mount -o loop,ro "$VIRTIO_ISO" "$tmp_iso" >/dev/null 2>&1 || fail "VIRTIO_ISO_MOUNT_FAILED" "Check ISO and sudo permissions."
for f in Balloon NetKVM viostor vioscsi; do [[ -d "$tmp_iso/$f" ]] || fail "VIRTIO_DRIVER_FOLDER_MISSING" "Missing $f in VirtIO ISO."; done
cleanup_iso
trap - EXIT

# Stale Method Z tmp mounts.
if mount | grep -q "$BASE_DIR/runs/.*/tmp"; then
  fail "STALE_METHOD_Z_MOUNT_FOUND" "Unmount stale guestmounts under $BASE_DIR/runs before running."
fi

# Disk space: at least 50G, or 2x source artifact if known.
avail_kb=$(df -Pk "$BASE_DIR" | awk 'NR==2 {print $4}')
required_kb=$((50 * 1024 * 1024))
if [[ -n "$SOURCE_ARTIFACT" && -s "$SOURCE_ARTIFACT" ]]; then
  src_bytes=$(stat -c %s "$SOURCE_ARTIFACT")
  src_req_kb=$(( (src_bytes * 2) / 1024 ))
  (( src_req_kb > required_kb )) && required_kb=$src_req_kb
fi
(( avail_kb >= required_kb )) || fail "INSUFFICIENT_DISK_SPACE" "Need at least $((required_kb/1024/1024))G free under $BASE_DIR."

[[ -n "${OS_AUTH_URL:-}" ]] || fail "OS_AUTH_URL_MISSING" "Source your Flex OpenRC before running Method Z."
openstack token issue >/dev/null 2>&1 || fail "OPENSTACK_TOKEN_FAILED" "Check OpenRC credentials."

for r in "$REGION" DFW3 IAD3 ORD3 ORD IAD DFW; do
  [[ -z "$r" ]] && continue
  if OS_REGION_NAME="$r" openstack image list --limit 1 >/dev/null 2>&1; then
    ACTUAL_IMAGE_REGION="$r"
    break
  fi
done
[[ -n "$ACTUAL_IMAGE_REGION" ]] || fail "OPENSTACK_IMAGE_REGION_NOT_FOUND" "Use a region where openstack image list works."

write_status SUCCESS
echo "METHOD_Z_PREFLIGHT_OK"
echo "actual_image_region=$ACTUAL_IMAGE_REGION"
echo "kvm_required=false"

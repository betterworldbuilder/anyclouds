#!/usr/bin/env bash
set -Eeuo pipefail

BASE_DIR="${OSPC2FLEX_METHOD_Z_BASE_DIR:-/mnt/migration/ospc2flex_method_z}"
LABEL=""
INPUT_ARTIFACT=""
REGION="${OS_REGION_NAME:-DFW3}"
VIRTIO_ISO="${OSPC2FLEX_VIRTIO_ISO:-}"
RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)-$$"
FLAVOR="${FLEX_FLAVOR:-}"
NETWORK="${FLEX_NETWORK:-}"
KEYPAIR="${FLEX_KEYPAIR:-}"
SEC_GROUP="${FLEX_SECURITY_GROUP:-default}"
BOOT_RESCUE=0

usage() {
  cat <<USAGE
Usage: $0 --label LABEL --input-artifact PATH [options]

Method Z no-local-hypervisor flow:
  reuse/copy qcow2 -> offline stage VirtIO drivers -> upload IDE/e1000 rescue image.

Options:
  --base-dir PATH
  --label LABEL
  --input-artifact PATH
  --region REGION
  --virtio-iso PATH
  --boot-rescue                Also boot rescue VM after upload
  --flavor FLAVOR
  --network NETWORK
  --keypair KEYPAIR
  --security-group GROUP
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --base-dir) BASE_DIR="$2"; shift 2 ;;
    --label) LABEL="$2"; shift 2 ;;
    --input-artifact) INPUT_ARTIFACT="$2"; shift 2 ;;
    --region) REGION="$2"; shift 2 ;;
    --virtio-iso) VIRTIO_ISO="$2"; shift 2 ;;
    --boot-rescue) BOOT_RESCUE=1; shift ;;
    --flavor) FLAVOR="$2"; shift 2 ;;
    --network) NETWORK="$2"; shift 2 ;;
    --keypair) KEYPAIR="$2"; shift 2 ;;
    --security-group) SEC_GROUP="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage; exit 2 ;;
  esac
done
[[ -n "$LABEL" && -n "$INPUT_ARTIFACT" ]] || { usage; exit 2; }
[[ -s "$INPUT_ARTIFACT" ]] || { echo "Input artifact missing: $INPUT_ARTIFACT" >&2; exit 1; }
[[ -n "$VIRTIO_ISO" ]] || VIRTIO_ISO="$BASE_DIR/cache/virtio/virtio-win.iso"

LABEL_SAFE="$(echo "$LABEL" | tr -cs 'A-Za-z0-9_.-' '_' | sed 's/_$//')"
JOB_DIR="$BASE_DIR/runs/$LABEL_SAFE/$RUN_ID"
JOB_ART="$JOB_DIR/artifacts"
JOB_LOG="$JOB_DIR/logs"
JOB_STATE="$JOB_DIR/state"
JOB_TMP="$JOB_DIR/tmp"
JOB_REPORT="$JOB_DIR/reports"
mkdir -p "$JOB_ART" "$JOB_LOG" "$JOB_STATE" "$JOB_TMP" "$JOB_REPORT"
LOG="$JOB_LOG/method_z.log"
RESULT="$JOB_STATE/result.json"

log() { printf '[%s] %s\n' "$(date -u +%FT%TZ)" "$*" | tee -a "$LOG"; }
write_result() {
  local status="$1" stage="$2" reason="${3:-}" next="${4:-}"
  python3 - <<PY > "$RESULT"
import json, os
print(json.dumps({
  "method":"Z_NO_KVM_FLEX_BIND",
  "status":"$status",
  "stage":"$stage",
  "run_id":"$RUN_ID",
  "label":"$LABEL_SAFE",
  "job_dir":"$JOB_DIR",
  "requested_region":"$REGION",
  "source_artifact":"$INPUT_ARTIFACT",
  "qcow2_artifact": os.environ.get("QCOW2", ""),
  "rescue_image_name": os.environ.get("IMAGE_NAME", ""),
  "failure_reason":"$reason",
  "next_action":"$next",
  "final": status in ("METHOD_Z_SUCCESS", "FAILED")
}, indent=2))
PY
}
fail() { log "FAILED: $1"; write_result FAILED "$2" "$1" "${3:-Review $LOG}"; exit 1; }

log "Method Z starting. No local KVM/libvirt boot is required."
write_result RUNNING PREFLIGHT
"$BASE_DIR/bin/method_z_preflight.sh" --base-dir "$BASE_DIR" --virtio-iso "$VIRTIO_ISO" --region "$REGION" --source-artifact "$INPUT_ARTIFACT" | tee -a "$LOG"

QCOW2="$JOB_ART/$LABEL_SAFE.flex-rescue.qcow2"
export QCOW2
write_result RUNNING ARTIFACT
case "$INPUT_ARTIFACT" in
  *dummy*|*.partial|*.tmp) fail "UNSAFE_INPUT_ARTIFACT" ARTIFACT "Use a real qcow2/raw/img/vhd/vhdx, not dummy/partial/tmp." ;;
esac
case "$INPUT_ARTIFACT" in
  *.qcow2) cp --reflink=auto "$INPUT_ARTIFACT" "$QCOW2" 2>/dev/null || cp -a "$INPUT_ARTIFACT" "$QCOW2" ;;
  *.raw|*.img|*.vhd|*.vhdx) qemu-img convert -O qcow2 "$INPUT_ARTIFACT" "$QCOW2" >>"$LOG" 2>&1 ;;
  *) fail "UNSUPPORTED_ARTIFACT_FORMAT" ARTIFACT "Use qcow2/raw/img/vhd/vhdx." ;;
esac
qemu-img check "$QCOW2" | tee -a "$LOG"

write_result RUNNING OFFLINE_PREP
MNT="$JOB_TMP/mnt"
ISO_MNT="$JOB_TMP/virtio_iso"
mkdir -p "$MNT" "$ISO_MNT"
sudo guestmount -a "$QCOW2" -i --rw "$MNT" >>"$LOG" 2>&1 || fail "GUESTMOUNT_FAILED" OFFLINE_PREP
cleanup_mounts() { sudo umount "$ISO_MNT" >/dev/null 2>&1 || true; sudo guestunmount "$MNT" >/dev/null 2>&1 || sudo umount "$MNT" >/dev/null 2>&1 || true; }
trap cleanup_mounts EXIT
sudo test -d "$MNT/Windows/System32/config" || fail "WINDOWS_CONFIG_NOT_FOUND" OFFLINE_PREP
sudo test -f "$MNT/Windows/System32/ntoskrnl.exe" || fail "WINDOWS_KERNEL_NOT_FOUND" OFFLINE_PREP
TS="$(date -u +%Y%m%dT%H%M%SZ)"
sudo mkdir -p "$MNT/ospc2flex/registry-backups/$TS"
for h in SYSTEM SOFTWARE SAM SECURITY DEFAULT; do
  sudo test -s "$MNT/Windows/System32/config/$h" || fail "WINDOWS_HIVE_MISSING_$h" OFFLINE_PREP
  if sudo test ! -s "$MNT/Windows/System32/config/$h.ospc2flex.bak"; then
    sudo cp -a "$MNT/Windows/System32/config/$h" "$MNT/Windows/System32/config/$h.ospc2flex.bak"
  fi
  sudo cp -a "$MNT/Windows/System32/config/$h" "$MNT/ospc2flex/registry-backups/$TS/$h"
done
sudo mount -o loop,ro "$VIRTIO_ISO" "$ISO_MNT" >>"$LOG" 2>&1 || fail "VIRTIO_ISO_MOUNT_FAILED" OFFLINE_PREP
sudo mkdir -p "$MNT/ospc2flex/drivers"
sudo rsync -a "$ISO_MNT/" "$MNT/ospc2flex/drivers/" >>"$LOG" 2>&1
sudo touch "$MNT/ospc2flex/.drivers_staged"
for d in Balloon NetKVM viostor vioscsi; do sudo test -d "$MNT/ospc2flex/drivers/$d" || fail "VIRTIO_FOLDER_MISSING_$d" OFFLINE_PREP; done
cleanup_mounts
trap - EXIT
qemu-img check "$QCOW2" | tee -a "$LOG"

write_result RUNNING UPLOAD_RESCUE
export OS_REGION_NAME="$REGION"
IMAGE_NAME="$LABEL_SAFE-$RUN_ID-z-rescue-ide"
export IMAGE_NAME
openstack image create --container-format bare --disk-format qcow2 --file "$QCOW2" --progress "$IMAGE_NAME" | tee -a "$LOG"
for i in {1..180}; do
  status="$(openstack image show "$IMAGE_NAME" -f value -c status 2>/dev/null || true)"
  log "image_status=$status"
  [[ "$status" == "active" ]] && break
  sleep 10
done
[[ "$(openstack image show "$IMAGE_NAME" -f value -c status)" == "active" ]] || fail "IMAGE_UPLOAD_NOT_ACTIVE" UPLOAD_RESCUE
openstack image set "$IMAGE_NAME" \
  --property hw_disk_bus=ide --property hw_cdrom_bus=ide --property hw_vif_model=e1000 \
  --property os_type=windows --property os_distro=windows --property vm_mode=hvm \
  --property ospc2flex_method=Z_NO_KVM_FLEX_BIND --property ospc2flex_run_id="$RUN_ID" --property ospc2flex_label="$LABEL_SAFE"

if [[ "$BOOT_RESCUE" == "1" ]]; then
  [[ -n "$FLAVOR" && -n "$NETWORK" ]] || fail "BOOT_VALUES_MISSING" RESCUE_BOOT "Set --flavor and --network."
  RESCUE_SERVER="$LABEL_SAFE-$RUN_ID-z-rescue"
  args=(server create --image "$IMAGE_NAME" --flavor "$FLAVOR" --network "$NETWORK" --security-group "$SEC_GROUP")
  [[ -n "$KEYPAIR" ]] && args+=(--key-name "$KEYPAIR")
  args+=("$RESCUE_SERVER")
  openstack "${args[@]}" | tee -a "$LOG"
fi

write_result METHOD_Z_SUCCESS UPLOAD_RESCUE
log "Method Z prepared and uploaded rescue image: $IMAGE_NAME"
log "Next stage: boot rescue VM, attach dummy volume, run pnputil in Windows, snapshot, then final virtio-scsi boot."

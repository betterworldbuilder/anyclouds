#!/usr/bin/env bash
set -Eeuo pipefail

RUN_ID=""
BASE_DIR="${OSPC2FLEX_METHOD_Z_BASE_DIR:-/mnt/migration/ospc2flex_method_z}"
DELETE_FINAL=0
DRY_RUN=0

usage() {
  cat <<USAGE
Usage: $0 --run-id RUN_ID [options]

Options:
  --base-dir PATH
  --delete-final    Also delete resources tagged as final for this run
  --dry-run
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --run-id) RUN_ID="$2"; shift 2 ;;
    --base-dir) BASE_DIR="$2"; shift 2 ;;
    --delete-final) DELETE_FINAL=1; shift ;;
    --dry-run) DRY_RUN=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage; exit 2 ;;
  esac
done
[[ -n "$RUN_ID" ]] || { usage; exit 2; }
run() { echo "+ $*"; [[ "$DRY_RUN" == "1" ]] || "$@"; }

# Best-effort OpenStack cleanup using Method Z metadata. Requires sourced OpenRC.
if command -v openstack >/dev/null 2>&1 && [[ -n "${OS_AUTH_URL:-}" ]]; then
  mapfile -t servers < <(openstack server list --long -f value -c ID -c Properties 2>/dev/null | awk -v r="$RUN_ID" '$0 ~ r {print $1}')
  for id in "${servers[@]:-}"; do run openstack server delete "$id" || true; done

  mapfile -t vols < <(openstack volume list --long -f value -c ID -c Properties 2>/dev/null | awk -v r="$RUN_ID" '$0 ~ r {print $1}')
  for id in "${vols[@]:-}"; do run openstack volume delete "$id" || true; done

  mapfile -t imgs < <(openstack image list --long -f value -c ID -c Properties 2>/dev/null | awk -v r="$RUN_ID" '$0 ~ r {print $1}')
  for id in "${imgs[@]:-}"; do
    if [[ "$DELETE_FINAL" == "1" ]]; then run openstack image delete "$id" || true; else echo "Keeping image $id unless --delete-final is used"; fi
  done
fi

echo "Cleanup completed for RUN_ID=$RUN_ID"

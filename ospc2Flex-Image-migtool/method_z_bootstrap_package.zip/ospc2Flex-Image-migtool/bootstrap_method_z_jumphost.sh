#!/usr/bin/env bash
set -Eeuo pipefail

DEFAULT_BASE_DIR="/mnt/migration/ospc2flex_method_z"
BASE_DIR="$DEFAULT_BASE_DIR"
VIRTIO_ISO=""
DOWNLOAD_VIRTIO=0
SKIP_APT=0
CHECK_OPENSTACK=0
REQUESTED_REGION="${OS_REGION_NAME:-DFW3}"
DRY_RUN=0
TS="$(date -u +%Y%m%dT%H%M%SZ)"
LOG_FILE=""
STATUS_FILE=""
ACTUAL_IMAGE_REGION=""
FAILURE_REASON=""
NEXT_ACTION=""

redact_env() {
  env | grep '^OS_' | sort | \
    sed -e 's/^OS_PASSWORD=.*/OS_PASSWORD=***REDACTED***/' \
        -e 's/^OS_TOKEN=.*/OS_TOKEN=***REDACTED***/' \
        -e 's/^OS_APPLICATION_CREDENTIAL_SECRET=.*/OS_APPLICATION_CREDENTIAL_SECRET=***REDACTED***/'
}

usage() {
  cat <<USAGE
Usage: $0 [options]

Options:
  --base-dir PATH       Base directory. Default: $DEFAULT_BASE_DIR
  --virtio-iso PATH     VirtIO ISO path. Default: BASE_DIR/cache/virtio/virtio-win.iso
  --download-virtio     Download virtio-win.iso if missing
  --skip-apt            Skip apt package installation
  --check-openstack     Validate OpenStack auth and image region
  --region REGION       Preferred OpenStack region. Default: OS_REGION_NAME or DFW3
  --dry-run             Print actions without changing system
  -h, --help            Show help
USAGE
}

log() { printf '[%s] %s\n' "$(date -u +%FT%TZ)" "$*" | tee -a "$LOG_FILE"; }
run() {
  log "+ $*"
  if [[ "$DRY_RUN" == "1" ]]; then return 0; fi
  "$@" 2>&1 | tee -a "$LOG_FILE"
}

json_escape() { python3 -c 'import json,sys; print(json.dumps(sys.argv[1]))' "$1"; }
write_status() {
  local status="$1"
  mkdir -p "$(dirname "$STATUS_FILE")"
  cat > "$STATUS_FILE" <<JSON
{
  "component": "method_z_jumphost_bootstrap",
  "status": "$status",
  "base_dir": $(json_escape "$BASE_DIR"),
  "virtio_iso": $(json_escape "$VIRTIO_ISO"),
  "virtio_iso_valid": ${VIRTIO_ISO_VALID:-false},
  "required_tools_ok": ${REQUIRED_TOOLS_OK:-false},
  "openstack_checked": ${OPENSTACK_CHECKED:-false},
  "requested_region": $(json_escape "$REQUESTED_REGION"),
  "actual_image_region": $(json_escape "$ACTUAL_IMAGE_REGION"),
  "dev_kvm_present": ${DEV_KVM_PRESENT:-false},
  "kvm_required": false,
  "timestamp": "$(date -u +%FT%TZ)",
  "failure_reason": $(json_escape "$FAILURE_REASON"),
  "next_action": $(json_escape "$NEXT_ACTION")
}
JSON
}

fail() {
  FAILURE_REASON="$1"
  NEXT_ACTION="${2:-Review $LOG_FILE and rerun bootstrap.}"
  log "FAILED: $FAILURE_REASON"
  log "NEXT_ACTION: $NEXT_ACTION"
  write_status "FAILED"
  exit 1
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --base-dir) BASE_DIR="$2"; shift 2 ;;
    --virtio-iso) VIRTIO_ISO="$2"; shift 2 ;;
    --download-virtio) DOWNLOAD_VIRTIO=1; shift ;;
    --skip-apt) SKIP_APT=1; shift ;;
    --check-openstack) CHECK_OPENSTACK=1; shift ;;
    --region) REQUESTED_REGION="$2"; shift 2 ;;
    --dry-run) DRY_RUN=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage; exit 2 ;;
  esac
done

if [[ -z "$VIRTIO_ISO" ]]; then
  VIRTIO_ISO="$BASE_DIR/cache/virtio/virtio-win.iso"
fi

LOG_FILE="$BASE_DIR/logs/bootstrap-$TS.log"
STATUS_FILE="$BASE_DIR/reports/bootstrap_status.json"

mkdir -p "$BASE_DIR"/logs "$BASE_DIR"/reports
trap 'rc=$?; if [[ $rc -ne 0 ]]; then FAILURE_REASON=${FAILURE_REASON:-BOOTSTRAP_INTERRUPTED}; NEXT_ACTION=${NEXT_ACTION:-Review logs and rerun safely.}; write_status FAILED; fi' EXIT

log "Method Z jumphost bootstrap starting"
log "Base dir: $BASE_DIR"
log "VirtIO ISO: $VIRTIO_ISO"
log "Method Z does not require local KVM. Missing /dev/kvm is acceptable."

# Base directories only; per-run dirs are created by Method Z.
for d in bin conf cache cache/virtio logs runs reports tmp bad_artifacts; do
  run mkdir -p "$BASE_DIR/$d"
done

if [[ "$SKIP_APT" != "1" ]]; then
  PACKAGES=(
    qemu-utils qemu-system-x86 nbd-client nbdkit ntfs-3g libguestfs-tools libhivex-bin chntpw
    python3 python3-pip python3-venv python3-openstackclient python3-cinderclient
    python3-glanceclient python3-novaclient python3-neutronclient jq curl netcat-openbsd
    openssh-client rsync unzip ca-certificates
  )
  log "Installing Method Z no-KVM dependencies. Uses libhivex-bin, not hivex."
  run sudo apt-get update
  run sudo DEBIAN_FRONTEND=noninteractive apt-get install -y "${PACKAGES[@]}"
else
  log "Skipping apt installation by request."
fi

required_cmds=(qemu-img qemu-nbd guestmount guestunmount hivexsh reged chntpw openstack jq curl nc ssh scp rsync python3)
missing=()
for c in "${required_cmds[@]}"; do
  if command -v "$c" >/dev/null 2>&1; then
    log "OK command: $c -> $(command -v "$c")"
  else
    log "MISSING command: $c"
    missing+=("$c")
  fi
done
if [[ ${#missing[@]} -gt 0 ]]; then
  REQUIRED_TOOLS_OK=false
  fail "REQUIRED_TOOLS_MISSING" "Install missing commands: ${missing[*]}"
fi
REQUIRED_TOOLS_OK=true

if [[ -e /dev/kvm ]]; then DEV_KVM_PRESENT=true; else DEV_KVM_PRESENT=false; fi
log "dev_kvm_present=$DEV_KVM_PRESENT"
log "cpu_virtualization_flags=$(egrep -c '(vmx|svm)' /proc/cpuinfo || true)"
log "KVM is not required for Method Z."

validate_iso() {
  local iso="$1"
  local iso_mnt
  iso_mnt="$(mktemp -d "$BASE_DIR/tmp/virtio-iso.XXXXXX")"
  trap 'sudo umount "$iso_mnt" >/dev/null 2>&1 || true; rmdir "$iso_mnt" >/dev/null 2>&1 || true' RETURN
  file "$iso" | tee -a "$LOG_FILE" | grep -qi 'ISO 9660' || return 1
  sudo mount -o loop,ro "$iso" "$iso_mnt" >>"$LOG_FILE" 2>&1
  for folder in Balloon NetKVM viostor vioscsi; do
    [[ -d "$iso_mnt/$folder" ]] || return 1
  done
  sudo umount "$iso_mnt" >>"$LOG_FILE" 2>&1 || true
  rmdir "$iso_mnt" >/dev/null 2>&1 || true
  trap - RETURN
  return 0
}

if [[ ! -s "$VIRTIO_ISO" && "$DOWNLOAD_VIRTIO" == "1" ]]; then
  run mkdir -p "$(dirname "$VIRTIO_ISO")"
  run curl -L --fail --retry 3 -o "$VIRTIO_ISO" \
    "https://fedorapeople.org/groups/virt/virtio-win/direct-downloads/stable-virtio/virtio-win.iso"
fi

if [[ ! -s "$VIRTIO_ISO" ]]; then
  VIRTIO_ISO_VALID=false
  fail "VIRTIO_ISO_MISSING" "Run with --download-virtio or place virtio-win.iso at $VIRTIO_ISO."
fi

if validate_iso "$VIRTIO_ISO"; then
  VIRTIO_ISO_VALID=true
  log "VirtIO ISO validated."
else
  VIRTIO_ISO_VALID=false
  fail "VIRTIO_ISO_INVALID" "Replace $VIRTIO_ISO with a valid virtio-win.iso."
fi

find_image_region() {
  local preferred="$1"
  local regions=()
  [[ -n "$preferred" ]] && regions+=("$preferred")
  regions+=(DFW3 IAD3 ORD3 ORD IAD DFW)
  local seen=""
  for r in "${regions[@]}"; do
    [[ " $seen " == *" $r "* ]] && continue
    seen+=" $r"
    log "Testing OpenStack image region: $r"
    if OS_REGION_NAME="$r" openstack image list --limit 1 >>"$LOG_FILE" 2>&1; then
      ACTUAL_IMAGE_REGION="$r"
      log "Working image region: $ACTUAL_IMAGE_REGION"
      return 0
    fi
  done
  return 1
}

if [[ "$CHECK_OPENSTACK" == "1" ]]; then
  OPENSTACK_CHECKED=true
  log "OpenStack env, redacted:"
  redact_env | tee -a "$LOG_FILE"
  [[ -n "${OS_AUTH_URL:-}" ]] || fail "OS_AUTH_URL_MISSING" "Source your Flex OpenRC first, then rerun with --check-openstack."
  openstack token issue >>"$LOG_FILE" 2>&1 || fail "OPENSTACK_TOKEN_FAILED" "Check OpenRC credentials on the jumphost."
  if ! find_image_region "$REQUESTED_REGION"; then
    fail "OPENSTACK_IMAGE_REGION_NOT_FOUND" "Set --region to a region where openstack image list works."
  fi
  OS_REGION_NAME="$ACTUAL_IMAGE_REGION" openstack flavor list --limit 1 >>"$LOG_FILE" 2>&1 || true
  OS_REGION_NAME="$ACTUAL_IMAGE_REGION" openstack network list --limit 1 >>"$LOG_FILE" 2>&1 || true
  OS_REGION_NAME="$ACTUAL_IMAGE_REGION" openstack volume list --limit 1 >>"$LOG_FILE" 2>&1 || true
else
  OPENSTACK_CHECKED=false
fi

write_status "SUCCESS"
log "Method Z jumphost bootstrap SUCCESS"
log "Status JSON: $STATUS_FILE"

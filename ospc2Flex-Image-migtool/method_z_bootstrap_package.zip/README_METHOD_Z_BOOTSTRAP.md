# Method Z — No-KVM Flex-side VirtIO Migration Bootstrap Package

This package prepares a jumphost for Method Z.

## Files

- `ospc2Flex-Image-migtool/bootstrap_method_z_jumphost.sh` — installs no-KVM dependencies, creates directory layout, validates/downloads VirtIO ISO, validates OpenStack region when requested.
- `ospc2Flex-Image-migtool/stage_method_z_to_jumphost.sh` — copies Method Z files to a remote jumphost and optionally runs bootstrap.
- `ospc2Flex-Image-migtool/method_z_required_files.txt` — required file manifest.
- `ospc2Flex-Image-migtool/method_z_preflight.sh` — reusable Method Z preflight.
- `ospc2Flex-Image-migtool/ospc2flex_windows_method_z_no_kvm_flex_bind.sh` — initial Method Z runner for existing qcow2/raw/img/vhd/vhdx to prepared Flex rescue image.
- `ospc2Flex-Image-migtool/cleanup_method_z_run.sh` — best-effort cleanup by Method Z run ID.

`workflow_dashboard/app.py` is intentionally not included here; dashboard integration can be patched later.

## Stage to jumphost

```bash
cd ospc2Flex-Image-migtool
./stage_method_z_to_jumphost.sh \
  --jumphost ubuntu@<jumphost-ip> \
  --ssh-key ~/.ssh/id_rsa \
  --remote-base /mnt/migration/ospc2flex_method_z \
  --bootstrap \
  --download-virtio \
  --region DFW3
```

For OpenStack checks, source your Flex OpenRC on the remote jumphost first, or explicitly copy one with `--copy-openrc` only when acceptable:

```bash
./stage_method_z_to_jumphost.sh \
  --jumphost ubuntu@<jumphost-ip> \
  --ssh-key ~/.ssh/id_rsa \
  --remote-base /mnt/migration/ospc2flex_method_z \
  --bootstrap \
  --download-virtio \
  --check-openstack \
  --region DFW3
```

## Run Method Z on jumphost

```bash
source ~/flex-openrc.sh
export OS_REGION_NAME=DFW3

/mnt/migration/ospc2flex_method_z/bin/ospc2flex_windows_method_z_no_kvm_flex_bind.sh \
  --label windows_2016-104.130.26.194 \
  --input-artifact /mnt/migration/ospc2flex_image/windows_2016-104.130.26.194.qcow2 \
  --region DFW3
```

This produces an IDE/e1000 rescue image. The next stages are booting rescue VM, attaching dummy VirtIO volume, running Windows `pnputil`, snapshotting, and final virtio-scsi boot.
